import java.util.ArrayList;
import java.util.List;

import org.jsoup.nodes.Document;


public class Buffer2014302580267 {
	List<Document> links=new ArrayList<Document>();
	List<String> names=new ArrayList<String>();
	boolean signal=true;
	
	
	
	public synchronized void addLink(Document d,String name) throws InterruptedException{
		while(!signal){
			System.err.println("Buffer is full now, crawler is waiting...");
			wait();
			
		}
		links.add(d);
		names.add(name);
		signal=false;
		System.err.println("Crawler has put an url into waitList");
		notify();
		
		
	}
	
	public synchronized Document getLink(int i) throws InterruptedException{
		while(signal){
			System.err.println("Crawling now, cannot parse...");
			wait();
		}
		notify();
		Document doc=links.get(i);
	
		
		
		return doc;
		
		
		//links.remove(0);
	}
	
	public synchronized String getName(int i) throws InterruptedException{
		while(signal){
			wait();
		}
		notify();
		String name=names.get(i);
		System.out.println("Get a link from wait list");
		
		
		signal=true;
		return name;
		
	}
}
	