import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
/**
 * the read class to read links from the first html
 * @author cxq
 *
 */
public class Read2014302580267 implements Runnable{
	private Buffer2014302580267 buffer;
	
	public Read2014302580267(Buffer2014302580267 buffer){
		this.buffer=buffer;
	}
	
	@Override
	public void run() {
		// TODO �Զ����ɵķ������
		
		Document doc;
		try {
			//get the document
			doc = Jsoup.connect("http://sc.xidian.edu.cn/html/teacher/daoshixinxi/").get();
			Elements trs=doc.getElementsByClass("middle_left_box1").get(0).getElementsByTag("tr");
			Element t=trs.get(2).getElementsByTag("td").get(1);
			Elements ele=t.getElementsByTag("a");
			
			for(int i=0;i<24;i++){
				//the 14th professor's link has something error
				if(i!=14){
				String link=ele.get(i).attr("href");
				Document d=Jsoup.connect(link).get();
				
				//get the name
				String name=ele.get(i).text();
				buffer.addLink(d,name);
				}
			}
		} catch (IOException | InterruptedException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		
		}
	
}


