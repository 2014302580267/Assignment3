import java.util.ArrayList;
import java.util.List;

import org.jsoup.nodes.Document;
/**
 * The buffer for links and name from html
 * @author Xiaoqiao Chen
 *
 */

public class Buffer2014302580267 {
	List<Document> links=new ArrayList<Document>();//the list for links of professors
	List<String> names=new ArrayList<String>();//the list for professors' names
	
	//the signal to ensure crawl once and parse once
	boolean signal=true;
	
	
	//add one link to links
	public synchronized void addLink(Document d,String name) throws InterruptedException{
		//when signal is false,can't add link
		while(!signal){
			System.err.println("Buffer is full now, crawler is waiting...");
			wait();
			
		}
		links.add(d);
		names.add(name);
		signal=false;
		System.err.println("Crawler has put an url into waitList");
		notify();
		
		
	}
	
	//get the ith link from links
	public synchronized Document getLink(int i) throws InterruptedException{
		//when signal is true,can't get link
		while(signal){
			System.err.println("Crawling now, cannot parse...");
			wait();
		}
		notify();
		Document doc=links.get(i);
	
		
		
		return doc;
		
		
	}
	//get the ith name from names
	public synchronized String getName(int i) throws InterruptedException{
		//when signal is true,can't get name
		while(signal){
			wait();
		}
		notify();
		String name=names.get(i);
		System.out.println("Get a link from wait list");
		
		
		signal=true;
		return name;
		
	}
}
	