import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
/**
 * The class to realize the function as single thread
 * @author Xiaoqiao Chen
 *
 */
public class SingleThread2014302580267 implements Runnable{
	//the run function
	public void run(){
		String url="jdbc:mysql://localhost:3306/Teacher?useUnicode=true&characterEncoding=utf-8";
		String user="root";
		String password="19950707";
		
		
		Document doc;
		try {
			
		//the loop to ensure every professor's information can be parsed
		for(int i=0;i<24;i++){
			//get the document
			doc = Jsoup.connect("http://sc.xidian.edu.cn/html/teacher/daoshixinxi/").get();
			Elements trs=doc.getElementsByClass("middle_left_box1").get(0).getElementsByTag("tr");
			Element t=trs.get(2).getElementsByTag("td").get(1);
			Elements ele=t.getElementsByTag("a");
			
			//the variable of database
			Connection conn=null;
			Statement st = null;
			
			try {
				//load the database
				Class.forName("com.mysql.jdbc.Driver");
				conn=DriverManager.getConnection(url, user, password);
				st=conn.createStatement();
				
				//the 14th professor's link has something error
				if(i==14)continue;
				
				//get the links and parse it
				String link=ele.get(i).attr("href");
				Document d=Jsoup.connect(link).get();
				
				//get the name
				String name=ele.get(i).text();
				
				//get the brief
				String brief="";
				Elements briefs=d.getElementById("n2").getElementsByTag("p");
				int n1=briefs.size();
				for(int j=0;j<n1;j++)
					brief=brief+briefs.get(j).text();
				
				//get the field
				String field=d.getElementById("n1").getElementsByTag("p").get(0).text();
				
				//get the contact
				String contact="";
				Elements contacts=d.getElementById("n3").getElementsByTag("p");
				int n2=contacts.size();
				for(int j=0;j<n2;j++)
					contact=contact+contacts.get(j).text();
				
				//truncate the table because the realization in multiple thread ways 
				if(i==0){
					String sql="truncate table TeacherList;";
					st.executeUpdate(sql);
				}
				
				//insert 
				String sql="insert into TeacherList(name,brief,field,contact) values('"+name+"','"+brief+"','"+field+"','"+contact+"');";
				
				try {
					st.executeUpdate(sql);
				} catch (SQLException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				
				}
		} catch (IOException e1) {
			// TODO �Զ����ɵ� catch ��
			e1.printStackTrace();
		}finally{
			//close the connection and statement
			st.close();
			conn.close();
			
		}
			}
			} catch (ClassNotFoundException | SQLException | IOException e) {
				// TODO �Զ����ɵ� catch ��
				System.out.println("Fail to conect to the database!");
				e.printStackTrace();
			}
	}
}
			
			
				