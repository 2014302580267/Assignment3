import java.io.IOException;
/**
 * the main class to test multiple thread and single thread
 * @author cxq
 *
 */

public class Main2014302580267 {
	public static void main(String[]args) throws InterruptedException, IOException{
		
		//create objects
		Buffer2014302580267 buffer=new Buffer2014302580267();
		Read2014302580267 read=new Read2014302580267(buffer);
		Parse2014302580267 parse=new Parse2014302580267(buffer);
		
		//create two thread for reading and writing
		Thread t1=new Thread(read);
		Thread t2=new Thread(parse);
		
		//the start time
		long startTime = System.currentTimeMillis();
		//two threads start
		t1.start();
		t2.start();
		t1.join();
		t2.join();
		
		//output the running time
		System.out.println("���߳�ʱ��: " + (System.currentTimeMillis() - startTime));
		
		
		
		
		//the single thread
		//the start time
		long startTime2 = System.currentTimeMillis();
		
		//create object
		SingleThread2014302580267 single=new SingleThread2014302580267();
		//create a thread 
		Thread t3=new Thread(single);
		//start the thread
		t3.start();
		t3.join();
		//output the running time
		System.out.println("���߳�ʱ��: " + (System.currentTimeMillis() - startTime2));
		}
	}

