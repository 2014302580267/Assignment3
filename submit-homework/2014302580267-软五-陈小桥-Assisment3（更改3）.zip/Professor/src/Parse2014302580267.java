import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
/**
 * parse each link from buffer
 * @author Xiaoqiao Chen
 *
 */

public class Parse2014302580267 implements Runnable{
	private Buffer2014302580267 buffer;
	
	//the information of database
	private String url="jdbc:mysql://localhost:3306/Teacher?useUnicode=true&characterEncoding=utf-8";
	private String user="root";
	private String password="19950707";
	private Statement st;
	
	public Parse2014302580267(Buffer2014302580267 buffer){
		this.buffer=buffer;
	}
	
	//parse one link
	public void parseDoc(int i) throws InterruptedException{
		Document doc=buffer.getLink(i);
		String name=buffer.getName(i);
		
		//get this professor's brief
		String brief="";
		Elements briefs=doc.getElementById("n2").getElementsByTag("p");
		int n1=briefs.size();
		for(int j=0;j<n1;j++)
			brief=brief+briefs.get(j).text();
		
		//get this professor's field
		String field=doc.getElementById("n1").getElementsByTag("p").get(0).text();
		
		//get this professor's contact
		String contact="";
		Elements contacts=doc.getElementById("n3").getElementsByTag("p");
		int n2=contacts.size();
		for(int j=0;j<n2;j++)
			contact=contact+contacts.get(j).text();
		
		//sql statement to insert the data to database
		String sql="insert into TeacherList(name,brief,field,contact) values('"+name+"','"+brief+"','"+field+"','"+contact+"');";
		
		try {
			st.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		
	}
	//load the database
	public void load(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection(url, user, password);
			st=conn.createStatement();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("Fail to conect to the database!");
			e.printStackTrace();
		}
		
	}
	
	
	@Override
	public void run() {
		// TODO �Զ����ɵķ������
		load();
		
		//to parse 23 links
		for(int i=0;i<23;i++){
		try {
			
			parseDoc(i);
			
			
		} catch (InterruptedException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		}
	}
	
	
}
